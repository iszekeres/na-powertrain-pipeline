# Slip Tables — RPM x Torque (9x9) — Format & How-To

This bundle standardizes per-gear TCC Desired Slip tables to the exact format shown in the project screenshots.

## Grid / Axes

- Shape: 9 x 9 (rows x columns)
- Columns (RPM, no header row in final files):
  1000, 1200, 1400, 1600, 1800, 2000, 2200, 2400, 4400
- Rows (Engine Torque, lb·ft, no header column in final files):
  0.00, 0.09, 36.88, 88.51, 103.26, 121.76, 132.70, 143.82, 184.39
- Cells: integer slip rpm

Final TSV files have **no headers** — just the 9x9 numeric grid.
Template included: `TEMPLATE__SlipTable__RPMxTORQUE__9x9__no_headers.tsv` (all cells = 10).

## How to generate from a cleaned log

1) Clean your raw CSV:  
```
python trans_clean_analyze.py --in "<raw_log.csv>" --map "AllChannels_PID_Name_Map__latest.csv"   --outdir "./06_Logs/Trans_Review" --final-drive 3.08 --speed-units mph --tft-warm-f 100
```
This writes `__trans_focus__clean__<base>.csv`.

2) Build slip tables (9x9, RPM x Torque):  
```
python gen_slip_tables_rpmxtrq.py --in "./06_Logs/Trans_Review/__trans_focus__clean__<base>.csv"   --outdir "./06_Logs/Trans_Review/SlipTables_Out" --fill 10
```
- Uses warmed-only samples (>= 100 F TFT).  
- Uses locked converter samples only (or infers lock via |slip| < 50 rpm).  
- Torque source priority: `trans_engine_torque` -> `delivered_engine_torque` -> `engine_torque`.  
- RPM bins: 1000,1200,1400,1600,1800,2000,2200,2400,4400  
- Torque bins: 0.00,0.09,36.88,88.51,103.26,121.76,132.70,143.82,184.39  
- Target policy: clamp median slip by RPM band (<=1600: 0–25, 1600–2200: 10–40, >2200: 20–60).  
- Output: one headerless TSV per gear, e.g. `Slip_G2__RPMxTORQUE__9x9__no_headers.tsv`.

## Minimal channels to log

Engine RPM, Vehicle Speed, Throttle %, Pedal %, Trans Current Gear, Trans Calculated Gear Ratio,
Turbine/Input RPM, Output RPM (10 ms), TCC Slip (and TCC lock flag), plus torque PIDs.