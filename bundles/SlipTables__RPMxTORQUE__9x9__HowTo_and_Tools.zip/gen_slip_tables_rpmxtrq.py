
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Generate per-gear TCC Desired Slip tables in a 9x9 RPM x Torque headerless TSV format.
# Columns (RPM): 1000,1200,1400,1600,1800,2000,2200,2400,4400
# Rows (Torque, lb-ft): 0.00,0.09,36.88,88.51,103.26,121.76,132.70,143.82,184.39
# Cells contain integer slip targets (rpm).

import argparse, pandas as pd, numpy as np
from pathlib import Path

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--in",  dest="infile", required=True, help="Path to __trans_focus__clean__*.csv")
    p.add_argument("--outdir", default="./06_Logs/Trans_Review/SlipTables_Out", help="Output directory")
    p.add_argument("--warm-f", type=float, default=100.0, help="TFT warmed threshold (F)")
    p.add_argument("--fill", type=int, default=10, help="Value to fill missing bins (keeps 9x9 complete)")
    p.add_argument("--rpm-bins", default="1000,1200,1400,1600,1800,2000,2200,2400,4400")
    p.add_argument("--torque-bins", default="0.00,0.09,36.88,88.51,103.26,121.76,132.70,143.82,184.39")
    return p.parse_args()

def to_num(s):
    return pd.to_numeric(s, errors="coerce")

def clamp_by_rpm(median_slip, rpm_center):
    if pd.isna(median_slip): return np.nan
    if rpm_center <= 1600: lo, hi = 0, 25
    elif rpm_center <= 2200: lo, hi = 10, 40
    else: lo, hi = 20, 60
    return float(np.clip(median_slip, lo, hi))

def main():
    args = parse_args()
    infile = Path(args.infile)
    outdir = Path(args.outdir); outdir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(infile)
    # Required columns
    needed = ["rpm","tcc_slip_rpm","gear_actual"]
    for c in needed:
        if c not in df.columns:
            raise SystemExit(f"Missing required column: {c}")
    slip = to_num(df["tcc_slip_rpm"])
    rpm  = to_num(df["rpm"])
    gear = to_num(df["gear_actual"]).astype("Int64")

    # Warmed-only mask
    tftF = to_num(df.get("trans_fluid_temp_f"))
    tftC = to_num(df.get("trans_fluid_temp_c"))
    if tftF.notna().any():
        warm = (tftF >= args.warm_f)
    elif tftC.notna().any():
        warm = (tftC >= ((args.warm_f - 32.0)*(5.0/9.0)))
    else:
        warm = pd.Series([True]*len(df))

    # Lock mask (use provided flag or infer)
    lock = df.get("tcc_locked")
    if lock is None:
        lock = slip.abs() < 50
    else:
        lock = lock.astype(bool)

    # Torque source priority
    trq = None
    for c in ["trans_engine_torque","delivered_engine_torque","engine_torque"]:
        if c in df.columns:
            trq = to_num(df[c])
            break
    # Build bins
    rpm_bins = [float(x.replace(",","")) for x in args.rpm_bins.split(",")]
    rpm_edges = rpm_bins + [rpm_bins[-1] + 200]  # close last bin
    trq_bins = [float(x) for x in args.torque_bins.split(",")]
    trq_edges = trq_bins + [trq_bins[-1] + 1e-6]  # small epsilon to close

    # Gears present
    gears = sorted(int(x) for x in gear.dropna().unique().tolist())
    for g in gears:
        # If torque missing entirely, output a filled grid (format-only) and continue
        if trq is None:
            out = np.full((9,9), int(args.fill), dtype=int)
            Path(outdir, f"Slip_G{g}__RPMxTORQUE__9x9__no_headers.tsv").write_text(
                "\n".join("\t".join(map(str,row)) for row in out) + "\n", encoding="utf-8"
            )
            continue

        mask = (gear == g) & warm & lock & rpm.notna() & slip.notna()
        if not mask.any():
            out = np.full((9,9), int(args.fill), dtype=int)
            Path(outdir, f"Slip_G{g}__RPMxTORQUE__9x9__no_headers.tsv").write_text(
                "\n".join("\t".join(map(str,row)) for row in out) + "\n", encoding="utf-8"
            )
            continue

        sub = pd.DataFrame({"rpm": rpm[mask], "slip": slip[mask], "trq": trq[mask]}).dropna()
        if sub.empty:
            out = np.full((9,9), int(args.fill), dtype=int)
            Path(outdir, f"Slip_G{g}__RPMxTORQUE__9x9__no_headers.tsv").write_text(
                "\n".join("\t".join(map(str,row)) for row in out) + "\n", encoding="utf-8"
            )
            continue

        sub["rpm_bin"] = pd.cut(sub["rpm"], bins=rpm_edges, right=False, include_lowest=True)
        sub["trq_bin"] = pd.cut(sub["trq"], bins=trq_edges, right=False, include_lowest=True)
        grp = sub.groupby(["trq_bin","rpm_bin"])["slip"].median().reset_index()
        if grp.empty:
            out = np.full((9,9), int(args.fill), dtype=int)
            Path(outdir, f"Slip_G{g}__RPMxTORQUE__9x9__no_headers.tsv").write_text(
                "\n".join("\t".join(map(str,row)) for row in out) + "\n", encoding="utf-8"
            )
            continue

        grp["rpm_center"] = grp["rpm_bin"].apply(lambda iv: (iv.left + iv.right)/2.0)
        grp["target"] = grp.apply(lambda r: clamp_by_rpm(r["slip"], r["rpm_center"]), axis=1)

        rpm_labels = [f"{int(x)}" for x in rpm_bins]
        trq_labels = [f"{x:.2f}" for x in trq_bins]
        grp["rlabel"] = grp["rpm_bin"].apply(lambda iv: f"{int(iv.left)}")
        grp["tlabel"] = grp["trq_bin"].apply(lambda iv: f"{iv.left:.2f}")
        piv = grp.pivot(index="tlabel", columns="rlabel", values="target")
        piv = piv.reindex(index=trq_labels, columns=rpm_labels)
        filled = piv.fillna(int(args.fill)).round(0).astype(int)

        out_tsv = "\n".join("\t".join(str(v) for v in filled.loc[t].tolist()) for t in trq_labels) + "\n"
        Path(outdir, f"Slip_G{g}__RPMxTORQUE__9x9__no_headers.tsv").write_text(out_tsv, encoding="utf-8")

    print(f"Saved per-gear slip tables to: {outdir}")

if __name__ == "__main__":
    main()
