# NA Transmission — SUPER HANDOFF (Slip + Shift + TCC)
Built: 2025-11-04T21:15:54

## What's included
- SlipTables/`NA_Trans_TCC_SlipTables__HandOff__LATEST.zip` — FINAL slip tables handoff (9×9 headerless TSVs + docs + generator).
- ShiftTables/`SHIFT_TABLES__Throttle17__HandOff__LATEST.zip` — Shift scheduling tables handoff (Throttle-17 format, header `mph … %`, labeled rows + generators).
- TCC/`TCC__Throttle17__PER_GEAR__HandOff__LATEST.zip` — TCC Apply/Release **per-gear** handoff (Throttle-17 format, sentinel policy, generator).
- `FORMAT_LOCK__VCM_Paste_Spec.txt` — the canonical, paste-ready formats for VCM Editor (CRITICAL).
- Examples/ — example outputs from the current run (`test1`) ready to paste.
- Channels/Trans-FAST.channels.xml — ParameterID-based VCM Scanner pack (if present).

## Quick run order (regenerate from a new log)
1. Run your pipeline to produce `__trans_focus__clean__*.csv`.
2. Generate Slip Tables (Hybrid 5–20) using the slip handoff package (do not change format or values).
3. Generate Shift Tables using `shift_tables_generate_from_log__Throttle17.py` (or synth version).
4. Generate TCC Apply/Release (per-gear) using `tcc_tables_generate_per_gear__Throttle17.py`.
5. Copy/paste into VCM Editor using the exact formats defined in the FORMAT LOCK.

**Slip tables are FINAL (do not modify).**
