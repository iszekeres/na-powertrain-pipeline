print('# placeholder – minimal engine cleaner')
