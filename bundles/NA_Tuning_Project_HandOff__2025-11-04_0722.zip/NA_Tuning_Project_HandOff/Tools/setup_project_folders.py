import argparse
from pathlib import Path
ROOT_FOLDERS = {"01_Planning":"Goals","02_Baseline":"Baseline","03_Parts_&_Invoices":"Parts","04_Tuning_Sessions":"Sessions","05_Maps_&_Calibrations":"Maps","06_Logs":"Logs","07_Dyno_&_Performance":"Dyno","08_Wiring_&_CAD":"CAD","09_Photos_&_Video":"Media","10_Docs_&_Notes":"Docs","ZZ_Archive":"Archive"}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root", required=True); args=ap.parse_args()
    root=Path(args.root).expanduser()
    for name in ROOT_FOLDERS:
        (root/name).mkdir(parents=True, exist_ok=True)
    print("Created")
if __name__=="__main__": main()
