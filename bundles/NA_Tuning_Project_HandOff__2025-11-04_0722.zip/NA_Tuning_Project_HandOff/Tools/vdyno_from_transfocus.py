print('# placeholder – windowed RWHP script')
