All-Channels PID ↔ Name Map
============================
This folder contains the canonical mapping between HP Tuners ParameterIDs and channel names
for your current ECM/OS. It was derived from the untrimmed CSV header provided on 2025-11-04.

Authoritative files:
- AllChannels_PID_Name_Map__latest.csv  (rolling latest)
- AllChannels_PID_Name_Map__2025-11-04.csv (dated snapshot)
- AllChannels_PID_Name_Map__2025-11-04.json
- AllChannels_PID_Name_Map__2025-11-04.yaml

Legacy/alias:
- Spark_PID_Name_Map__latest.csv (kept for backward compatibility)

How to regenerate from a new header:
1) Export or paste the **first two header rows** (line 1 = PIDs, line 2 = names) from a VCM Scanner CSV.
2) Share them here and say: "update pid map".
3) I will parse and overwrite the *_latest files and add a dated snapshot.

How to use:
- Look up ParameterIDs from names via name_to_pid (JSON/YAML).
- When generating channels.xml, resolve each desired channel's PID using this map, then emit:
  <channel ParameterID="PID"/>
